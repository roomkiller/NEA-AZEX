import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Eye, Globe, Shield, Activity } from 'lucide-react';

export default function SignalFeedItem({ signal }) {
    const getTypeIcon = (type) => {
        switch (type) {
            case 'OSINT': return Globe;
            case 'Social_Media': return Activity;
            case 'Dark_Web': return Shield;
            case 'Anomalie_Statistique': return Eye;
            default: return Activity;
        }
    };

    const getTypeColor = (type) => {
        const colors = {
            'OSINT': 'text-blue-400',
            'Social_Media': 'text-purple-400',
            'Dark_Web': 'text-red-400',
            'Anomalie_Statistique': 'text-cyan-400'
        };
        return colors[type] || 'text-gray-400';
    };

    const getPriorityColor = (priority) => {
        switch (priority) {
            case 'Critique': return 'bg-red-500/20 text-red-400';
            case 'Élevé': return 'bg-orange-500/20 text-orange-400';
            case 'Moyen': return 'bg-yellow-500/20 text-yellow-400';
            case 'Bas': return 'bg-green-500/20 text-green-400';
            default: return 'bg-gray-500/20 text-gray-400';
        }
    };

    const TypeIcon = getTypeIcon(signal.signal_type);

    return (
        <div className="p-3 rounded-lg bg-[var(--nea-bg-surface-hover)] border border-[var(--nea-border-subtle)] hover:border-[var(--nea-primary-blue)] transition-all">
            <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg bg-[var(--nea-bg-surface)] ${getTypeColor(signal.signal_type)}`}>
                    <TypeIcon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                        <Badge className={`${getPriorityColor(signal.priority_level)} border-0 text-xs`}>
                            {signal.priority_level}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                            {signal.signal_type.replace(/_/g, ' ')}
                        </Badge>
                        <span className="text-xs text-[var(--nea-text-secondary)]">
                            {new Date(signal.detection_timestamp).toLocaleTimeString('fr-CA')}
                        </span>
                    </div>
                    <h4 className="font-semibold text-[var(--nea-text-title)] text-sm mb-1">
                        {signal.signal_title}
                    </h4>
                    <p className="text-xs text-[var(--nea-text-secondary)] mb-2">
                        {signal.content_summary?.substring(0, 150)}...
                    </p>
                    <div className="flex items-center justify-between">
                        <span className="text-xs text-[var(--nea-text-secondary)]">
                            Source: {signal.source_platform}
                        </span>
                        <Badge variant="outline" className="text-xs">
                            {signal.relevance_score}% pertinence
                        </Badge>
                    </div>
                </div>
            </div>
        </div>
    );
}