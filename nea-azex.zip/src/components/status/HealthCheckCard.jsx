import React from 'react';
import { motion } from 'framer-motion';
import NeaCard from '../ui/NeaCard';
import { Activity, CheckCircle, AlertTriangle, XCircle, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const STATUS_CONFIG = {
    Healthy: {
        icon: CheckCircle,
        color: 'text-green-400',
        bg: 'bg-green-500/10',
        label: 'Sain',
        borderColor: 'border-green-500/30'
    },
    Warning: {
        icon: AlertTriangle,
        color: 'text-yellow-400',
        bg: 'bg-yellow-500/10',
        label: 'Attention',
        borderColor: 'border-yellow-500/30'
    },
    Critical: {
        icon: XCircle,
        color: 'text-red-400',
        bg: 'bg-red-500/10',
        label: 'Critique',
        borderColor: 'border-red-500/30'
    },
    Unknown: {
        icon: Clock,
        color: 'text-gray-400',
        bg: 'bg-gray-500/10',
        label: 'Inconnu',
        borderColor: 'border-gray-500/30'
    }
};

export default function HealthCheckCard({ system }) {
    if (!system) {
        return (
            <NeaCard>
                <div className="p-8 text-center">
                    <Activity className="w-12 h-12 text-gray-600 dark:text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 dark:text-gray-400">
                        Aucune donnée de santé système disponible
                    </p>
                </div>
            </NeaCard>
        );
    }

    const statusConfig = STATUS_CONFIG[system.status] || STATUS_CONFIG.Unknown;
    const StatusIcon = statusConfig.icon;
    const uptime = system.uptime || 0;
    const healthScore = system.health_score || 0;
    const checks = system.checks || [];

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
        >
            <NeaCard className={`border-2 ${statusConfig.borderColor}`}>
                <div className="p-6 space-y-6">
                    {/* En-tête avec Status */}
                    <div className="flex items-start justify-between">
                        <div className="flex items-center gap-4">
                            <div className={`w-16 h-16 rounded-lg ${statusConfig.bg} flex items-center justify-center`}>
                                <StatusIcon className={`w-8 h-8 ${statusConfig.color}`} />
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">
                                    {system.name || 'Système'}
                                </h3>
                                <Badge className={`${statusConfig.bg} ${statusConfig.color} border-0`}>
                                    {statusConfig.label}
                                </Badge>
                            </div>
                        </div>
                    </div>

                    {/* Métriques Principales */}
                    <div className="grid md:grid-cols-2 gap-4">
                        <NeaCard className="p-4 bg-[var(--nea-bg-surface-hover)]">
                            <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                                Score de Santé
                            </p>
                            <div className="space-y-2">
                                <div className="flex items-baseline gap-2">
                                    <span className={`text-3xl font-bold ${
                                        healthScore >= 90 ? 'text-green-400' :
                                        healthScore >= 70 ? 'text-yellow-400' :
                                        'text-red-400'
                                    }`}>
                                        {healthScore}
                                    </span>
                                    <span className="text-lg text-gray-600 dark:text-gray-400">/ 100</span>
                                </div>
                                <Progress value={healthScore} className="h-2" />
                            </div>
                        </NeaCard>

                        <NeaCard className="p-4 bg-[var(--nea-bg-surface-hover)]">
                            <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                                Temps de Fonctionnement
                            </p>
                            <div className="flex items-baseline gap-2">
                                <span className="text-3xl font-bold text-blue-400">
                                    {uptime}
                                </span>
                                <span className="text-lg text-gray-600 dark:text-gray-400">%</span>
                            </div>
                            <Progress value={uptime} className="h-2 mt-2" />
                        </NeaCard>
                    </div>

                    {/* Vérifications de Santé */}
                    {checks.length > 0 && (
                        <div>
                            <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
                                Vérifications de Santé
                            </h4>
                            <div className="space-y-2">
                                {checks.map((check, index) => {
                                    const checkConfig = STATUS_CONFIG[check.status] || STATUS_CONFIG.Unknown;
                                    const CheckIcon = checkConfig.icon;

                                    return (
                                        <motion.div
                                            key={index}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: index * 0.05 }}
                                            className={`p-3 rounded-lg border ${checkConfig.bg} ${checkConfig.borderColor} flex items-center justify-between`}
                                        >
                                            <div className="flex items-center gap-3">
                                                <CheckIcon className={`w-5 h-5 ${checkConfig.color}`} />
                                                <div>
                                                    <p className="text-sm font-semibold text-gray-900 dark:text-white">
                                                        {check.name}
                                                    </p>
                                                    {check.message && (
                                                        <p className="text-xs text-gray-600 dark:text-gray-400">
                                                            {check.message}
                                                        </p>
                                                    )}
                                                </div>
                                            </div>
                                            {check.response_time && (
                                                <span className="text-xs text-gray-600 dark:text-gray-400">
                                                    {check.response_time}ms
                                                </span>
                                            )}
                                        </motion.div>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    {/* Dernière Vérification */}
                    {system.last_check_time && (
                        <div className="pt-4 border-t border-[var(--nea-border-subtle)] text-xs text-gray-600 dark:text-gray-400 text-center">
                            Dernière vérification: {new Date(system.last_check_time).toLocaleString('fr-CA')}
                        </div>
                    )}
                </div>
            </NeaCard>
        </motion.div>
    );
}