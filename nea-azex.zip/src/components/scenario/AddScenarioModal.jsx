import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Layers, Save, Target, Calendar, FileText, Shield } from 'lucide-react';
import EnhancedDialog, { DialogSection, DialogField, EnhancedInput, EnhancedTextarea } from '../ui/EnhancedDialog';
import NeaButton from '../ui/NeaButton';

const SCENARIO_TYPES = ['Géopolitique', 'Nucléaire', 'Climatique', 'Biologique', 'Cybernétique', 'Hybride'];
const PERSPECTIVES = ['Militaire', 'Civile', 'Diplomatique', 'Humanitaire', 'Économique', 'Multi-angle'];
const PROBABILITIES = ['Faible', 'Moyenne', 'Élevée', 'Très élevée'];
const IMPACTS = ['Mineur', 'Modéré', 'Majeur', 'Catastrophique'];

export default function AddScenarioModal({ onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    scenario_name: '',
    scenario_type: 'Géopolitique',
    description: '',
    perspective: 'Multi-angle',
    timeline: {
      start_date: new Date().toISOString().split('T')[0],
      end_date: '',
      duration_days: 30
    },
    risk_assessment: {
      probability: 'Moyenne',
      impact: 'Modéré',
      mitigation_strategies: []
    },
    status: 'Brouillon'
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.scenario_name || !formData.description) {
      toast.error('Nom et description requis');
      return;
    }

    try {
      await base44.entities.Scenario.create(formData);
      toast.success('Scénario créé avec succès');
      if (onSuccess) onSuccess();
      onClose();
    } catch (error) {
      console.error('Error creating scenario:', error);
      toast.error('Erreur lors de la création');
    }
  };

  return (
    <EnhancedDialog
      open={true}
      onOpenChange={onClose}
      title="Nouveau Scénario Stratégique"
      description="Définissez un scénario d'analyse prospective pour évaluation des risques"
      icon={Layers}
      iconColor="text-purple-400"
      iconBg="from-purple-500/20 to-blue-500/30"
      headerGradient="from-purple-500/10 via-blue-500/10 to-cyan-500/10"
      size="lg"
      footer={
        <div className="flex justify-end gap-3">
          <NeaButton type="button" onClick={onClose} variant="ghost">
            Annuler
          </NeaButton>
          <NeaButton type="submit" onClick={handleSubmit}>
            <Save className="w-4 h-4 mr-2" />
            Créer le Scénario
          </NeaButton>
        </div>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Identification */}
        <DialogSection title="Identification" icon={FileText}>
          <DialogField label="Nom du Scénario" required>
            <EnhancedInput
              placeholder="Ex: Escalade tensions Iran-Israël 2025"
              value={formData.scenario_name}
              onChange={(e) => setFormData({ ...formData, scenario_name: e.target.value })}
            />
          </DialogField>

          <div className="grid grid-cols-2 gap-4">
            <DialogField label="Type de Scénario">
              <Select
                value={formData.scenario_type}
                onValueChange={(value) => setFormData({ ...formData, scenario_type: value })}
              >
                <SelectTrigger className="bg-[var(--nea-bg-surface-hover)] border-2 border-[var(--nea-border-default)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[var(--nea-bg-surface)] border-[var(--nea-border-default)]">
                  {SCENARIO_TYPES.map(type => (
                    <SelectItem key={type} value={type} className="text-white hover:bg-[var(--nea-bg-surface-hover)]">
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </DialogField>

            <DialogField label="Perspective d'Analyse">
              <Select
                value={formData.perspective}
                onValueChange={(value) => setFormData({ ...formData, perspective: value })}
              >
                <SelectTrigger className="bg-[var(--nea-bg-surface-hover)] border-2 border-[var(--nea-border-default)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[var(--nea-bg-surface)] border-[var(--nea-border-default)]">
                  {PERSPECTIVES.map(persp => (
                    <SelectItem key={persp} value={persp} className="text-white hover:bg-[var(--nea-bg-surface-hover)]">
                      {persp}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </DialogField>
          </div>

          <DialogField label="Description" required help="Décrivez le contexte et les enjeux du scénario">
            <EnhancedTextarea
              placeholder="Contexte géopolitique, acteurs impliqués, déclencheurs potentiels..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
            />
          </DialogField>
        </DialogSection>

        {/* Timeline */}
        <DialogSection title="Chronologie" icon={Calendar}>
          <div className="grid grid-cols-3 gap-4">
            <DialogField label="Date de Début">
              <EnhancedInput
                type="date"
                value={formData.timeline.start_date}
                onChange={(e) => setFormData({
                  ...formData,
                  timeline: { ...formData.timeline, start_date: e.target.value }
                })}
              />
            </DialogField>

            <DialogField label="Date de Fin">
              <EnhancedInput
                type="date"
                value={formData.timeline.end_date}
                onChange={(e) => setFormData({
                  ...formData,
                  timeline: { ...formData.timeline, end_date: e.target.value }
                })}
              />
            </DialogField>

            <DialogField label="Durée (jours)">
              <EnhancedInput
                type="number"
                min="1"
                placeholder="30"
                value={formData.timeline.duration_days}
                onChange={(e) => setFormData({
                  ...formData,
                  timeline: { ...formData.timeline, duration_days: parseInt(e.target.value) || 30 }
                })}
              />
            </DialogField>
          </div>
        </DialogSection>

        {/* Évaluation des Risques */}
        <DialogSection title="Évaluation des Risques" icon={Shield}>
          <div className="grid grid-cols-2 gap-4">
            <DialogField label="Probabilité">
              <Select
                value={formData.risk_assessment.probability}
                onValueChange={(value) => setFormData({
                  ...formData,
                  risk_assessment: { ...formData.risk_assessment, probability: value }
                })}
              >
                <SelectTrigger className="bg-[var(--nea-bg-surface-hover)] border-2 border-[var(--nea-border-default)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[var(--nea-bg-surface)] border-[var(--nea-border-default)]">
                  {PROBABILITIES.map(prob => (
                    <SelectItem key={prob} value={prob} className="text-white hover:bg-[var(--nea-bg-surface-hover)]">
                      {prob}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </DialogField>

            <DialogField label="Impact Potentiel">
              <Select
                value={formData.risk_assessment.impact}
                onValueChange={(value) => setFormData({
                  ...formData,
                  risk_assessment: { ...formData.risk_assessment, impact: value }
                })}
              >
                <SelectTrigger className="bg-[var(--nea-bg-surface-hover)] border-2 border-[var(--nea-border-default)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[var(--nea-bg-surface)] border-[var(--nea-border-default)]">
                  {IMPACTS.map(impact => (
                    <SelectItem key={impact} value={impact} className="text-white hover:bg-[var(--nea-bg-surface-hover)]">
                      {impact}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </DialogField>
          </div>
        </DialogSection>
      </form>
    </EnhancedDialog>
  );
}