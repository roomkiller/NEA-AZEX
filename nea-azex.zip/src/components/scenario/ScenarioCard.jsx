import React from 'react';
import NeaCard from '../ui/NeaCard';
import { Badge } from '@/components/ui/badge';
import { Eye, FileText, Image } from 'lucide-react';
import NeaButton from '../ui/NeaButton';

const TYPE_CONFIG = {
    'Géopolitique': { color: 'bg-red-500/10 text-red-400 border-red-500/30' },
    'Nucléaire': { color: 'bg-orange-500/10 text-orange-400 border-orange-500/30' },
    'Climatique': { color: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
    'Biologique': { color: 'bg-green-500/10 text-green-400 border-green-500/30' },
    'Cybernétique': { color: 'bg-purple-500/10 text-purple-400 border-purple-500/30' },
    'Hybride': { color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' },
};

const STATUS_CONFIG = {
    'Brouillon': { color: 'bg-gray-500/10 text-gray-400 border-gray-500/30' },
    'En génération': { color: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
    'Complété': { color: 'bg-green-500/10 text-green-400 border-green-500/30' },
    'Validé': { color: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30' },
    'Archivé': { color: 'bg-gray-500/10 text-gray-400 border-gray-500/30' },
};

export default function ScenarioCard({ scenario, onUpdate }) {
    const typeConfig = TYPE_CONFIG[scenario.scenario_type] || TYPE_CONFIG['Hybride'];
    const statusConfig = STATUS_CONFIG[scenario.status] || STATUS_CONFIG['Brouillon'];

    const hasMedia = scenario.media_assets && (
        scenario.media_assets.images?.length > 0 || 
        scenario.media_assets.videos?.length > 0
    );

    return (
        <NeaCard className="overflow-hidden hover:border-[var(--nea-primary-blue)]/50 transition-all duration-300">
            <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                    <div>
                        <h3 className="text-lg font-bold text-[var(--nea-text-title)] mb-2">{scenario.scenario_name}</h3>
                        <div className="flex items-center gap-2">
                            <Badge className={`${typeConfig.color} border text-xs`}>
                                {scenario.scenario_type}
                            </Badge>
                            <Badge className={`${statusConfig.color} border text-xs`}>
                                {scenario.status}
                            </Badge>
                        </div>
                    </div>
                </div>

                {scenario.description && (
                    <p className="text-sm text-[var(--nea-text-secondary)] line-clamp-3 mb-4">
                        {scenario.description}
                    </p>
                )}

                <div className="space-y-2 mb-4 text-sm">
                    <div className="flex justify-between">
                        <span className="text-[var(--nea-text-secondary)]">Perspective:</span>
                        <span className="text-[var(--nea-text-primary)] font-medium">{scenario.perspective}</span>
                    </div>
                    {scenario.timeline && (
                        <div className="flex justify-between">
                            <span className="text-[var(--nea-text-secondary)]">Durée:</span>
                            <span className="text-[var(--nea-text-primary)] font-medium">
                                {scenario.timeline.duration_days} jours
                            </span>
                        </div>
                    )}
                    {hasMedia && (
                        <div className="flex items-center gap-3 pt-2">
                            {scenario.media_assets.images?.length > 0 && (
                                <div className="flex items-center gap-1 text-xs text-[var(--nea-text-secondary)]">
                                    <Image className="w-3 h-3" />
                                    <span>{scenario.media_assets.images.length}</span>
                                </div>
                            )}
                            {scenario.media_assets.videos?.length > 0 && (
                                <div className="flex items-center gap-1 text-xs text-[var(--nea-text-secondary)]">
                                    <FileText className="w-3 h-3" />
                                    <span>{scenario.media_assets.videos.length}</span>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <NeaButton size="sm" variant="secondary" className="w-full">
                    <Eye className="w-4 h-4 mr-2" />
                    Voir les détails
                </NeaButton>
            </div>
        </NeaCard>
    );
}