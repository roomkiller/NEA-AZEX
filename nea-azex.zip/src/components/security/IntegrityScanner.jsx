import React, { useState, useEffect } from 'react';
import NeaCard from '../ui/NeaCard';
import { DataIntegrityCheck } from '@/api/entities';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const STATUS_CONFIG = {
  'Pass': { icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/20' },
  'Fail': { icon: XCircle, color: 'text-red-400', bg: 'bg-red-500/20' },
  'Warning': { icon: AlertTriangle, color: 'text-yellow-400', bg: 'bg-yellow-500/20' },
  'Repaired': { icon: ShieldCheck, color: 'text-blue-400', bg: 'bg-blue-500/20' }
};

export default function IntegrityScanner() {
  const [checks, setChecks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadChecks();
  }, []);

  const loadChecks = async () => {
    try {
      const data = await DataIntegrityCheck.list({ sort: '-check_timestamp', limit: 5 });
      setChecks(data);
    } catch (error) {
      console.error('Erreur chargement vérifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <NeaCard className="p-8 text-center">
        <p className="text-[var(--nea-text-secondary)]">Analyse en cours...</p>
      </NeaCard>
    );
  }

  const failedChecks = checks.filter(c => c.status === 'Fail').length;

  return (
    <NeaCard>
      <div className="p-4 border-b border-[var(--nea-border-default)] flex items-center justify-between">
        <h3 className="font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-blue-400" />
          Vérifications d'Intégrité
        </h3>
        <Badge className={failedChecks > 0 ? 'bg-red-500/20 text-red-300 border-0' : 'bg-green-500/20 text-green-300 border-0'}>
          {failedChecks} échecs
        </Badge>
      </div>

      <div className="divide-y divide-[var(--nea-border-default)]">
        {checks.map((check, index) => {
          const statusConfig = STATUS_CONFIG[check.status] || STATUS_CONFIG['Pass'];
          const StatusIcon = statusConfig.icon;
          
          return (
            <motion.div
              key={check.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-4"
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${statusConfig.bg}`}>
                  <StatusIcon className={`w-4 h-4 ${statusConfig.color}`} />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-white">{check.check_type.replace(/_/g, ' ')}</h4>
                  <p className="text-sm text-[var(--nea-text-secondary)] mt-1">
                    Entité: <span className="text-white">{check.entity_name}</span>
                  </p>
                  {check.integrity_score !== undefined && (
                    <p className="text-sm text-[var(--nea-text-secondary)] mt-1">
                      Score: <span className="text-white font-semibold">{check.integrity_score}/100</span>
                    </p>
                  )}
                </div>
                <Badge className={`${statusConfig.bg} ${statusConfig.color} border-0`}>
                  {check.status}
                </Badge>
              </div>
            </motion.div>
          );
        })}
      </div>
    </NeaCard>
  );
}