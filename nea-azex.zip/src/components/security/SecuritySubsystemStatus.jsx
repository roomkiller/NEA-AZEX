import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, CheckCircle, AlertTriangle, XCircle, Activity } from 'lucide-react';
import NeaCard from '../ui/NeaCard';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const SUBSYSTEMS = [
    { id: 'firewall', name: 'Pare-feu', icon: Shield },
    { id: 'intrusion', name: 'Détection Intrusion', icon: Activity },
    { id: 'encryption', name: 'Chiffrement', icon: Shield },
    { id: 'monitoring', name: 'Surveillance', icon: Activity }
];

export default function SecuritySubsystemStatus() {
    const [subsystems, setSubsystems] = useState([]);

    useEffect(() => {
        // Simulation de l'état des sous-systèmes
        const initializeSubsystems = () => {
            const statuses = ['operational', 'warning', 'critical'];
            return SUBSYSTEMS.map(sub => ({
                ...sub,
                status: statuses[Math.floor(Math.random() * statuses.length)],
                uptime: 95 + Math.random() * 5
            }));
        };

        setSubsystems(initializeSubsystems());
    }, []);

    const getStatusConfig = (status) => {
        const configs = {
            operational: {
                icon: CheckCircle,
                color: 'text-green-400',
                badgeColor: 'bg-green-500/20 text-green-400 border-green-500/30',
                label: 'Opérationnel'
            },
            warning: {
                icon: AlertTriangle,
                color: 'text-yellow-400',
                badgeColor: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
                label: 'Attention'
            },
            critical: {
                icon: XCircle,
                color: 'text-red-400',
                badgeColor: 'bg-red-500/20 text-red-400 border-red-500/30',
                label: 'Critique'
            }
        };
        return configs[status] || configs.operational;
    };

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)]">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                    Sous-systèmes de Sécurité
                </h3>
            </div>
            <div className="p-6 space-y-4">
                <AnimatePresence>
                    {subsystems.map((sub, index) => {
                        const config = getStatusConfig(sub.status);
                        const StatusIcon = config.icon;
                        const SubIcon = sub.icon;

                        return (
                            <motion.div
                                key={sub.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: index * 0.1 }}
                                className="p-4 bg-[var(--nea-bg-surface-hover)] rounded-lg"
                            >
                                <div className="flex items-center justify-between mb-3">
                                    <div className="flex items-center gap-3">
                                        <SubIcon className="w-5 h-5 text-[var(--nea-text-secondary)]" />
                                        <span className="font-semibold text-gray-900 dark:text-white">
                                            {sub.name}
                                        </span>
                                    </div>
                                    <Badge className={`${config.badgeColor} border flex items-center gap-1`}>
                                        <StatusIcon className="w-3 h-3" />
                                        {config.label}
                                    </Badge>
                                </div>
                                <div className="space-y-2">
                                    <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400">
                                        <span>Disponibilité</span>
                                        <span className="font-semibold">{sub.uptime.toFixed(1)}%</span>
                                    </div>
                                    <Progress value={sub.uptime} className="h-2" />
                                </div>
                            </motion.div>
                        );
                    })}
                </AnimatePresence>
            </div>
        </NeaCard>
    );
}