import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DataIntegrityCheck } from '@/api/entities';
import NeaCard from '../ui/NeaCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  ShieldCheck,
  Play,
  Pause,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Wrench,
  ChevronDown,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';

const STATUS_CONFIG = {
  Pass: { icon: CheckCircle, color: 'text-green-400', bg: 'bg-green-500/20', label: 'Réussi' },
  Fail: { icon: XCircle, color: 'text-red-400', bg: 'bg-red-500/20', label: 'Échoué' },
  Warning: { icon: AlertTriangle, color: 'text-yellow-400', bg: 'bg-yellow-500/20', label: 'Avertissement' },
  Repaired: { icon: Wrench, color: 'text-blue-400', bg: 'bg-blue-500/20', label: 'Réparé' }
};

export default function IntegrityScannerPro() {
  const [checks, setChecks] = useState([]);
  const [isScanning, setIsScanning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [expandedCheck, setExpandedCheck] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadChecks();
  }, []);

  const loadChecks = async () => {
    try {
      const data = await DataIntegrityCheck.list({ sort: '-check_timestamp', limit: 20 });
      setChecks(data);
    } catch (error) {
      console.error('Erreur chargement vérifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartScan = useCallback(async () => {
    setIsScanning(true);
    setScanProgress(0);
    setIsPaused(false);
    toast.info('Scan d\'intégrité démarré');

    // Simulation de scan progressif
    for (let i = 0; i <= 100; i += 10) {
      if (isPaused) break;
      setScanProgress(i);
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setIsScanning(false);
    toast.success('Scan d\'intégrité complété');
    loadChecks();
  }, [isPaused]);

  const handlePauseScan = () => {
    setIsPaused(!isPaused);
    toast.info(isPaused ? 'Scan repris' : 'Scan mis en pause');
  };

  const handleRepair = async (checkId) => {
    try {
      await DataIntegrityCheck.update(checkId, {
        status: 'Repaired',
        auto_repair_attempted: true,
        repair_status: 'Success'
      });
      toast.success('Réparation effectuée');
      loadChecks();
    } catch (error) {
      toast.error('Échec de la réparation');
    }
  };

  const stats = {
    total: checks.length,
    pass: checks.filter(c => c.status === 'Pass').length,
    fail: checks.filter(c => c.status === 'Fail').length,
    warning: checks.filter(c => c.status === 'Warning').length
  };

  if (isLoading) {
    return (
      <NeaCard className="p-8 text-center">
        <Loader2 className="w-8 h-8 mx-auto animate-spin text-[var(--nea-primary-blue)] mb-3" />
        <p className="text-[var(--nea-text-secondary)]">Chargement des vérifications...</p>
      </NeaCard>
    );
  }

  return (
    <NeaCard>
      <div className="p-4 border-b border-[var(--nea-border-default)]">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
            Scanner d'Intégrité Avancé
          </h3>
          <div className="flex items-center gap-2">
            <Button
              onClick={handleStartScan}
              disabled={isScanning}
              size="sm"
              className="bg-[var(--nea-primary-blue)] hover:bg-sky-500"
            >
              {isScanning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Scan en cours...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Lancer Scan
                </>
              )}
            </Button>
            {isScanning && (
              <Button onClick={handlePauseScan} size="sm" variant="outline">
                <Pause className="w-4 h-4 mr-2" />
                {isPaused ? 'Reprendre' : 'Pause'}
              </Button>
            )}
            <Button onClick={loadChecks} size="sm" variant="outline">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {isScanning && (
          <div className="space-y-2">
            <Progress value={scanProgress} className="h-2" />
            <p className="text-xs text-[var(--nea-text-secondary)]">Progression: {scanProgress}%</p>
          </div>
        )}

        <div className="grid grid-cols-4 gap-3 mt-4">
          <div className="p-3 rounded-lg bg-[var(--nea-bg-surface-hover)]">
            <p className="text-xs text-[var(--nea-text-secondary)]">Total</p>
            <p className="text-xl font-bold text-white">{stats.total}</p>
          </div>
          <div className="p-3 rounded-lg bg-green-500/10">
            <p className="text-xs text-green-400">Réussis</p>
            <p className="text-xl font-bold text-green-400">{stats.pass}</p>
          </div>
          <div className="p-3 rounded-lg bg-red-500/10">
            <p className="text-xs text-red-400">Échoués</p>
            <p className="text-xl font-bold text-red-400">{stats.fail}</p>
          </div>
          <div className="p-3 rounded-lg bg-yellow-500/10">
            <p className="text-xs text-yellow-400">Avertissements</p>
            <p className="text-xl font-bold text-yellow-400">{stats.warning}</p>
          </div>
        </div>
      </div>

      <div className="divide-y divide-[var(--nea-border-default)] max-h-96 overflow-y-auto styled-scrollbar">
        <AnimatePresence>
          {checks.map((check, index) => {
            const statusConfig = STATUS_CONFIG[check.status] || STATUS_CONFIG.Pass;
            const StatusIcon = statusConfig.icon;
            const isExpanded = expandedCheck === check.id;

            return (
              <motion.div
                key={check.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.03 }}
                className="p-4"
              >
                <div
                  className="flex items-start justify-between cursor-pointer"
                  onClick={() => setExpandedCheck(isExpanded ? null : check.id)}
                >
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`p-2 rounded-lg ${statusConfig.bg}`}>
                      <StatusIcon className={`w-4 h-4 ${statusConfig.color}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-white">{check.check_type.replace(/_/g, ' ')}</h4>
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-[var(--nea-text-secondary)]" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-[var(--nea-text-secondary)]" />
                        )}
                      </div>
                      <p className="text-sm text-[var(--nea-text-secondary)] mt-1">
                        {check.entity_name} • {new Date(check.check_timestamp).toLocaleString('fr-CA')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`${statusConfig.bg} ${statusConfig.color} border-0`}>
                      {statusConfig.label}
                    </Badge>
                    {check.status === 'Fail' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRepair(check.id);
                        }}
                      >
                        <Wrench className="w-3 h-3 mr-1" />
                        Réparer
                      </Button>
                    )}
                  </div>
                </div>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="ml-14 mt-3 space-y-2 text-sm"
                    >
                      {check.integrity_score !== undefined && (
                        <p className="text-[var(--nea-text-secondary)]">
                          Score d'intégrité: <span className="text-white font-semibold">{check.integrity_score}/100</span>
                        </p>
                      )}
                      {check.anomalies_detected && check.anomalies_detected.length > 0 && (
                        <div>
                          <p className="text-[var(--nea-text-secondary)] mb-2">Anomalies détectées:</p>
                          <ul className="space-y-1">
                            {check.anomalies_detected.map((anomaly, idx) => (
                              <li key={idx} className="text-xs text-red-300 flex items-start gap-2">
                                <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                                <span>{anomaly.field}: {anomaly.anomaly_type}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {check.check_duration_ms && (
                        <p className="text-[var(--nea-text-secondary)]">
                          Durée: <span className="text-white">{check.check_duration_ms}ms</span>
                        </p>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </NeaCard>
  );
}