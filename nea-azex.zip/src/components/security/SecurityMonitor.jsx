import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import NeaCard from '../ui/NeaCard';
import { AlertTriangle, CheckCircle, Shield, Activity } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SecurityMonitor() {
    const [incidents, setIncidents] = useState([]);
    const [stats, setStats] = useState({ total: 0, blocked: 0, critical: 0 });

    useEffect(() => {
        const loadIncidents = async () => {
            try {
                const data = await base44.entities.SecurityIncident.list({ sort: '-detected_timestamp', limit: 10 });
                setIncidents(data);
                setStats({
                    total: data.length,
                    blocked: data.filter(i => i.blocked).length,
                    critical: data.filter(i => i.severity === 'Critique').length
                });
            } catch (error) {
                console.error("Erreur chargement incidents:", error);
            }
        };
        loadIncidents();
        const interval = setInterval(loadIncidents, 15000);
        return () => clearInterval(interval);
    }, []);

    const getSeverityColor = (severity) => {
        switch(severity) {
            case 'Critique': return 'bg-red-500/10 text-red-400 border-red-500/30';
            case 'Élevé': return 'bg-orange-500/10 text-orange-400 border-orange-500/30';
            case 'Moyen': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30';
            case 'Faible': return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
            default: return 'bg-gray-500/10 text-gray-400 border-gray-500/30';
        }
    };

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)]">
                <h3 className="text-lg font-bold text-[var(--nea-text-title)]">Moniteur de Sécurité</h3>
            </div>
            <div className="p-6">
                <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-[var(--nea-bg-steel-gray)] rounded-lg">
                        <Activity className="w-8 h-8 mx-auto text-blue-400 mb-2" />
                        <p className="text-2xl font-bold text-[var(--nea-text-title)]">{stats.total}</p>
                        <p className="text-sm text-[var(--nea-text-secondary)]">Incidents détectés</p>
                    </div>
                    <div className="text-center p-4 bg-[var(--nea-bg-steel-gray)] rounded-lg">
                        <Shield className="w-8 h-8 mx-auto text-green-400 mb-2" />
                        <p className="text-2xl font-bold text-[var(--nea-text-title)]">{stats.blocked}</p>
                        <p className="text-sm text-[var(--nea-text-secondary)]">Attaques bloquées</p>
                    </div>
                    <div className="text-center p-4 bg-[var(--nea-bg-steel-gray)] rounded-lg">
                        <AlertTriangle className="w-8 h-8 mx-auto text-red-400 mb-2" />
                        <p className="text-2xl font-bold text-[var(--nea-text-title)]">{stats.critical}</p>
                        <p className="text-sm text-[var(--nea-text-secondary)]">Critiques</p>
                    </div>
                </div>

                <div className="space-y-3">
                    <h4 className="font-semibold text-[var(--nea-text-title)]">Incidents récents</h4>
                    {incidents.slice(0, 5).map((incident) => (
                        <div key={incident.id} className="p-4 bg-[var(--nea-bg-steel-gray)] rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <Badge className={`${getSeverityColor(incident.severity)} border`}>
                                        {incident.severity}
                                    </Badge>
                                    <span className="font-semibold text-[var(--nea-text-primary)]">{incident.incident_type}</span>
                                </div>
                                {incident.blocked ? (
                                    <CheckCircle className="w-5 h-5 text-green-400" />
                                ) : (
                                    <AlertTriangle className="w-5 h-5 text-red-400" />
                                )}
                            </div>
                            <div className="text-sm space-y-1">
                                <p className="text-[var(--nea-text-secondary)]">Source: {incident.source_ip}</p>
                                <p className="text-[var(--nea-text-muted)]">
                                    {new Date(incident.detected_timestamp).toLocaleString('fr-CA')}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </NeaCard>
    );
}