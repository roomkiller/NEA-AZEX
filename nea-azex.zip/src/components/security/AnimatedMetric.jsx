import React, { useEffect, useRef } from 'react';
import { animate } from 'framer-motion';

export default function AnimatedMetric({ value, duration = 1, className = '' }) {
    const nodeRef = useRef(null);

    useEffect(() => {
        const node = nodeRef.current;
        if (!node) return;

        const controls = animate(0, parseFloat(value) || 0, {
            duration,
            ease: 'easeOut',
            onUpdate(v) {
                if (node) {
                    node.textContent = v.toFixed(0);
                }
            }
        });

        return () => controls.stop();
    }, [value, duration]);

    return (
        <span ref={nodeRef} className={className}>
            0
        </span>
    );
}