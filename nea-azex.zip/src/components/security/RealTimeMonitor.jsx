import React, { useState, useEffect } from 'react';
import NeaCard from '../ui/NeaCard';
import AnimatedMetric from './AnimatedMetric';
import { Activity, Shield, AlertTriangle, Zap } from 'lucide-react';

export default function RealTimeMonitor() {
    const [metrics, setMetrics] = useState({
        activeConnections: 0,
        blockedAttempts: 0,
        scansRunning: 0,
        avgResponseTime: 0
    });

    useEffect(() => {
        const updateMetrics = () => {
            setMetrics({
                activeConnections: Math.floor(Math.random() * 500) + 100,
                blockedAttempts: Math.floor(Math.random() * 50),
                scansRunning: Math.floor(Math.random() * 10),
                avgResponseTime: Math.floor(Math.random() * 100) + 50
            });
        };

        updateMetrics();
        const interval = setInterval(updateMetrics, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)]">
                <h3 className="text-lg font-bold text-[var(--nea-text-title)]">Surveillance en Temps Réel</h3>
            </div>
            <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-6">
                <AnimatedMetric
                    icon={Activity}
                    label="Connexions actives"
                    value={metrics.activeConnections}
                    color="text-blue-400"
                />
                <AnimatedMetric
                    icon={Shield}
                    label="Tentatives bloquées"
                    value={metrics.blockedAttempts}
                    color="text-green-400"
                />
                <AnimatedMetric
                    icon={AlertTriangle}
                    label="Scans en cours"
                    value={metrics.scansRunning}
                    color="text-yellow-400"
                />
                <AnimatedMetric
                    icon={Zap}
                    label="Temps de réponse (ms)"
                    value={metrics.avgResponseTime}
                    color="text-purple-400"
                />
            </div>
        </NeaCard>
    );
}