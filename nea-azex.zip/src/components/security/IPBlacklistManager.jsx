import React, { useState, useEffect } from 'react';
import NeaCard from '../ui/NeaCard';
import { IPBlacklist } from '@/api/entities';
import { ListX, Plus, Globe } from 'lucide-react';
import NeaButton from '../ui/NeaButton';

export default function IPBlacklistManager() {
    const [blacklist, setBlacklist] = useState([]);

    useEffect(() => {
        const fetchBlacklist = async () => {
            const data = await IPBlacklist.list('-created_date', 5);
            setBlacklist(data);
        };
        fetchBlacklist();
    }, []);

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)] flex justify-between items-center">
                <h3 className="font-bold text-white flex items-center gap-2">
                    <ListX className="w-5 h-5 text-orange-400" />
                    IP Blacklistées
                </h3>
                 <NeaButton variant="ghost" size="sm"><Plus className="w-4 h-4 mr-1"/> Ajouter</NeaButton>
            </div>
            <div className="p-4 space-y-3">
                {blacklist.length > 0 ? blacklist.map(item => (
                    <div key={item.id} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                             <Globe className="w-4 h-4 text-[var(--nea-text-secondary)]" />
                             <p className="font-mono text-white">{item.ip_address}</p>
                        </div>
                        <p className="text-[var(--nea-text-muted)] truncate max-w-[150px]">{item.reason}</p>
                    </div>
                )) : (
                     <p className="text-sm text-center text-[var(--nea-text-secondary)] py-4">Aucune IP récemment blacklistée.</p>
                )}
            </div>
        </NeaCard>
    );
}