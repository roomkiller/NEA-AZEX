import React, { useState, useEffect } from 'react';
import NeaCard from '../ui/NeaCard';
import { base44 } from '@/api/base44Client';
import { Shield, AlertTriangle, Target } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function ThreatDashboard() {
    const [incidents, setIncidents] = useState([]);
    const [threatScore, setThreatScore] = useState(0);

    useEffect(() => {
        const loadData = async () => {
            try {
                const data = await base44.entities.SecurityIncident.list({ sort: '-threat_score', limit: 5 });
                setIncidents(data);
                const avgScore = data.length > 0 
                    ? data.reduce((sum, i) => sum + (i.threat_score || 0), 0) / data.length 
                    : 0;
                setThreatScore(Math.round(avgScore));
            } catch (error) {
                console.error("Erreur chargement menaces:", error);
            }
        };
        loadData();
        const interval = setInterval(loadData, 20000);
        return () => clearInterval(interval);
    }, []);

    const getThreatColor = (score) => {
        if (score >= 75) return 'text-red-400';
        if (score >= 50) return 'text-yellow-400';
        return 'text-green-400';
    };

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)]">
                <h3 className="text-lg font-bold text-[var(--nea-text-title)]">Tableau de Menaces</h3>
            </div>
            <div className="p-6">
                <div className="text-center mb-6">
                    <Shield className={`w-16 h-16 mx-auto ${getThreatColor(threatScore)} mb-3`} />
                    <p className="text-sm text-[var(--nea-text-secondary)] mb-2">Score de Menace Global</p>
                    <p className={`text-5xl font-bold ${getThreatColor(threatScore)}`}>{threatScore}</p>
                </div>

                <div className="space-y-3">
                    <h4 className="font-semibold text-[var(--nea-text-title)]">Menaces prioritaires</h4>
                    {incidents.map((incident) => (
                        <div key={incident.id} className="p-4 bg-[var(--nea-bg-steel-gray)] rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                    <Target className={`w-4 h-4 ${getThreatColor(incident.threat_score)}`} />
                                    <span className="font-semibold text-[var(--nea-text-primary)]">{incident.incident_type}</span>
                                </div>
                                <Badge className={`${getThreatColor(incident.threat_score)} border-current`}>
                                    Score: {incident.threat_score}
                                </Badge>
                            </div>
                            <p className="text-sm text-[var(--nea-text-secondary)]">IP: {incident.source_ip}</p>
                            {incident.source_geolocation?.country && (
                                <p className="text-xs text-[var(--nea-text-muted)]">
                                    Origine: {incident.source_geolocation.country}
                                </p>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </NeaCard>
    );
}