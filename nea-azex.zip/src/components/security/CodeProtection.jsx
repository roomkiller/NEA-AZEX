import React, { useState } from 'react';
import NeaCard from '../ui/NeaCard';
import NeaButton from '../ui/NeaButton';
import { Loader2, CheckCircle, Shield } from 'lucide-react';
import { toast } from 'sonner';

export default function CodeProtection() {
    const [isObfuscating, setIsObfuscating] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const [obfuscationStatus, setObfuscationStatus] = useState('Actif');
    const [lastScan, setLastScan] = useState(new Date());

    const handleObfuscate = () => {
        setIsObfuscating(true);
        toast.info("Lancement du processus de brouillage dynamique...");
        setTimeout(() => {
            setObfuscationStatus('Dynamique en temps réel');
            setIsObfuscating(false);
            toast.success("Le brouillage dynamique du code est maintenant actif.");
        }, 2500);
    };

    const handleScan = () => {
        setIsScanning(true);
        toast.info("Analyse d'intégrité du code source en cours...");
        setTimeout(() => {
            setLastScan(new Date());
            setIsScanning(false);
            toast.success("Analyse terminée. Aucune anomalie détectée.");
        }, 3500);
    };

    return (
        <NeaCard>
            <div className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Armure du Code Source</h3>
                <div className="space-y-5">
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--nea-text-secondary)]">Chiffrement du code</span>
                        <span className="font-bold text-green-400">AES-256 & RSA-8192</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--nea-text-secondary)]">Brouillage du code</span>
                        <span className="font-bold text-cyan-400">{obfuscationStatus}</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-[var(--nea-text-secondary)]">Dernière analyse d'intégrité</span>
                        <span className="font-mono text-xs text-white">{lastScan.toLocaleString('fr-CA')}</span>
                    </div>
                </div>
                <div className="mt-6 pt-6 border-t border-[var(--nea-border-secondary)] flex flex-col sm:flex-row gap-4">
                    <NeaButton onClick={handleObfuscate} disabled={isObfuscating || obfuscationStatus === 'Dynamique en temps réel'} className="flex-1">
                        {isObfuscating ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Shield className="w-4 h-4 mr-2" />}
                        Activer Brouillage Dynamique
                    </NeaButton>
                    <NeaButton onClick={handleScan} variant="secondary" disabled={isScanning} className="flex-1">
                        {isScanning ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <CheckCircle className="w-4 h-4 mr-2" />}
                        Lancer Analyse d'Intégrité
                    </NeaButton>
                </div>
            </div>
        </NeaCard>
    );
}