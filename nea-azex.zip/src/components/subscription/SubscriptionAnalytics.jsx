import React, { useState, useEffect } from 'react';
import { Subscription } from '@/api/entities';
import { motion } from 'framer-motion';
import NeaCard from '../ui/NeaCard';
import AnimatedMetric from '../security/AnimatedMetric';
import { DollarSign, Users, TrendingUp, TrendingDown } from 'lucide-react';
import { useStaggerAnimation } from '../navigation/PageTransition';

const SubscriptionAnalytics = () => {
    const [stats, setStats] = useState({ mrr: 0, activeSubs: 0, churnRate: 0 });
    const { containerVariants, itemVariants } = useStaggerAnimation(0.1);

    useEffect(() => {
        const calculateStats = async () => {
            const subscriptions = await Subscription.list();
            
            const activeSubscriptions = subscriptions.filter(s => s.status === 'Active');
            
            const mrr = activeSubscriptions.reduce((acc, sub) => {
                 if (sub.billing_cycle === 'Yearly') {
                    return acc + (sub.monthly_price / 12); // Approximation if only monthly price is stored
                 }
                 return acc + (sub.monthly_price || 0);
            }, 0);

            const cancelledThisMonth = subscriptions.filter(s => {
                const now = new Date();
                const cancelDate = new Date(s.cancelled_date);
                return s.status === 'Cancelled' && cancelDate.getMonth() === now.getMonth() && cancelDate.getFullYear() === now.getFullYear();
            }).length;

            const totalLastMonth = subscriptions.length - activeSubscriptions.length + cancelledThisMonth;
            const churn = totalLastMonth > 0 ? (cancelledThisMonth / totalLastMonth) * 100 : 0;

            setStats({
                mrr: mrr,
                activeSubs: activeSubscriptions.length,
                churnRate: churn
            });
        };

        calculateStats();
    }, []);

    return (
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <motion.div variants={itemVariants}>
                <NeaCard className="p-4">
                    <AnimatedMetric 
                        label="Revenu Mensuel Récurrent (MRR)" 
                        value={`$${stats.mrr.toFixed(2)}`} 
                        icon={<DollarSign className="text-green-400"/>} 
                    />
                </NeaCard>
            </motion.div>
            <motion.div variants={itemVariants}>
                <NeaCard className="p-4">
                    <AnimatedMetric 
                        label="Abonnements Actifs" 
                        value={stats.activeSubs} 
                        icon={<Users className="text-blue-400"/>}
                    />
                </NeaCard>
            </motion.div>
            <motion.div variants={itemVariants}>
                <NeaCard className="p-4">
                    <AnimatedMetric 
                        label="Taux de Désabonnement (Churn)" 
                        value={`${stats.churnRate.toFixed(1)}%`} 
                        icon={stats.churnRate > 5 ? <TrendingDown className="text-red-500"/> : <TrendingUp className="text-green-500"/>}
                    />
                </NeaCard>
            </motion.div>
        </motion.div>
    );
}

export default SubscriptionAnalytics;