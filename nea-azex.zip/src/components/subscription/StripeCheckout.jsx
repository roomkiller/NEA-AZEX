import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Subscription } from '@/api/entities';
import { StripeTransaction } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Loader2, CheckCircle, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

const StripeCheckout = ({ plan, user, onBack }) => {
    const [status, setStatus] = useState('processing');
    const navigate = useNavigate();

    useEffect(() => {
        const processSubscription = async () => {
            try {
                // 1. Simulate Stripe transaction
                const transaction = await StripeTransaction.create({
                    user_email: user.email,
                    plan_code: plan.plan_code,
                    amount: plan.monthly_price * 100, // Stripe uses cents
                    billing_cycle: 'monthly',
                    status: 'processing',
                });

                // 2. Deactivate previous subscriptions
                const existingSubs = await Subscription.filter({ user_email: user.email, status: 'Active' });
                for (const sub of existingSubs) {
                    await Subscription.update(sub.id, { status: 'Cancelled', auto_renew: false });
                }

                // 3. Create new subscription
                const startDate = new Date();
                const nextBillingDate = new Date(startDate);
                nextBillingDate.setMonth(nextBillingDate.getMonth() + 1);

                const newSubscription = await Subscription.create({
                    user_email: user.email,
                    plan_code: plan.plan_code,
                    plan_name: plan.plan_name,
                    status: 'Active',
                    billing_cycle: 'Monthly',
                    start_date: startDate.toISOString(),
                    end_date: nextBillingDate.toISOString(), // For monthly cycle
                    next_billing_date: nextBillingDate.toISOString(),
                    auto_renew: true,
                    monthly_price: plan.monthly_price,
                });
                
                // 4. Create first invoice
                await Invoice.create({
                    invoice_number: `INV-${Date.now()}`,
                    user_email: user.email,
                    subscription_id: newSubscription.id,
                    invoice_date: new Date().toISOString(),
                    due_date: new Date().toISOString(),
                    line_items: [{ description: `Abonnement ${plan.plan_name} - Mensuel`, quantity: 1, unit_price: plan.monthly_price, total: plan.monthly_price }],
                    subtotal: plan.monthly_price,
                    tax_rate: 14.975,
                    tax_amount: plan.monthly_price * 0.14975,
                    total_amount: plan.monthly_price * 1.14975,
                    status: 'Paid',
                    paid_date: new Date().toISOString()
                });

                // 5. Update transaction status
                await StripeTransaction.update(transaction.id, {
                    status: 'completed',
                    payment_status: 'paid',
                    subscription_id: newSubscription.id,
                    completed_at: new Date().toISOString(),
                });

                setStatus('completed');
                toast.success(`Félicitations! Vous êtes maintenant abonné au forfait ${plan.plan_name}.`);

                setTimeout(() => {
                    navigate(createPageUrl('MySubscription'));
                }, 2000);

            } catch (error) {
                console.error("Erreur de souscription:", error);
                toast.error("Une erreur est survenue lors de la souscription.");
                setStatus('failed');
            }
        };

        processSubscription();
    }, [plan, user, navigate]);

    return (
        <div className="min-h-screen bg-[var(--nea-bg-deep-space)] flex items-center justify-center p-6 tech-pattern">
            <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-[var(--nea-bg-surface)] border border-[var(--nea-border-default)] rounded-xl p-8 max-w-md w-full text-center"
            >
                <ShieldCheck className="w-16 h-16 mx-auto text-[var(--nea-primary-blue)] mb-6" />
                <h2 className="text-2xl font-bold text-white">Transaction Sécurisée</h2>
                <p className="text-[var(--nea-text-secondary)] mt-2">
                    Finalisation de votre abonnement au forfait <span className="text-white font-semibold">{plan.plan_name}</span>.
                </p>

                <div className="mt-8">
                    {status === 'processing' && (
                        <div className="flex items-center justify-center gap-3">
                            <Loader2 className="w-6 h-6 text-[var(--nea-primary-blue)] animate-spin" />
                            <span className="text-lg text-white">Traitement en cours...</span>
                        </div>
                    )}
                    {status === 'completed' && (
                         <div className="flex items-center justify-center gap-3 text-green-400">
                            <CheckCircle className="w-6 h-6" />
                            <span className="text-lg">Abonnement Activé!</span>
                        </div>
                    )}
                     {status === 'failed' && (
                        <p className="text-red-500">Le paiement a échoué. Veuillez réessayer.</p>
                    )}
                </div>
                 <p className="text-xs text-[var(--nea-text-muted)] mt-8">Simulation de paiement. Aucune vraie transaction n'a lieu.</p>
            </motion.div>
        </div>
    );
};

export default StripeCheckout;