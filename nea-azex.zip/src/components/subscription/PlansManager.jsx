import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, PlusCircle, Edit, DollarSign } from 'lucide-react';
import NeaCard from '../ui/NeaCard';
import NeaButton from '../ui/NeaButton';
import EmptyState from '../ui/EmptyState';
import AddPlanModal from './AddPlanModal';

const PlanCard = ({ plan, onEdit }) => (
    <NeaCard className="p-6 flex flex-col">
        <div className="flex-grow">
            <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">{plan.plan_name}</h3>
                {plan.is_popular && <div className="text-xs bg-yellow-400/20 text-yellow-300 px-2 py-1 rounded-full font-semibold">Populaire</div>}
            </div>
            <p className="text-[var(--nea-text-secondary)] mt-1 text-sm">{plan.description}</p>
            <div className="my-6">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">${plan.monthly_price}</span>
                <span className="text-[var(--nea-text-secondary)]">/mois</span>
            </div>
            <ul className="space-y-2 text-sm">
                {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded-full bg-green-500/30 flex items-center justify-center">
                            <span className="w-2 h-2 rounded-full bg-green-500"></span>
                        </span>
                        <span className="text-[var(--nea-text-primary)]">{feature}</span>
                    </li>
                ))}
            </ul>
        </div>
        <div className="mt-6">
             <NeaButton variant="secondary" className="w-full" onClick={() => onEdit(plan)}>
                <Edit className="w-4 h-4 mr-2" />
                Modifier le forfait
            </NeaButton>
        </div>
    </NeaCard>
);

const PlansManager = () => {
    const [plans, setPlans] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPlan, setEditingPlan] = useState(null);

    const fetchPlans = async () => {
        setIsLoading(true);
        try {
            const fetchedPlans = await base44.entities.SubscriptionPlan.list('display_order');
            setPlans(fetchedPlans);
        } catch (error) {
            console.error("Error fetching plans:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchPlans();
    }, []);

    const handleOpenModal = (plan = null) => {
        setEditingPlan(plan);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingPlan(null);
        fetchPlans();
    };

    if (isLoading) {
        return <div className="flex justify-center items-center p-8"><Loader2 className="animate-spin text-gray-900 dark:text-white" /></div>;
    }

    return (
        <div>
            <div className="flex justify-end mb-4">
                <NeaButton onClick={() => handleOpenModal()}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Ajouter un forfait
                </NeaButton>
            </div>
            {plans.length === 0 ? (
                <EmptyState
                    icon={DollarSign}
                    title="Aucun forfait"
                    description="Créez votre premier forfait pour commencer à vendre des abonnements."
                />
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {plans.map(plan => (
                        <PlanCard key={plan.id} plan={plan} onEdit={handleOpenModal} />
                    ))}
                </div>
            )}
             {isModalOpen && (
                <AddPlanModal
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    plan={editingPlan}
                />
            )}
        </div>
    );
};

export default PlansManager;