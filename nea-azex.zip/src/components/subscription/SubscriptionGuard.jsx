
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Subscription } from "@/api/entities";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Lock, AlertTriangle, CreditCard, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

/**
 * SYSTÈME DE PROTECTION PAR ABONNEMENT
 * Vérifie que l'utilisateur a le bon plan pour accéder à une page
 */

const PLAN_HIERARCHY = {
  'DISCOVERY': 1,
  'SOLO': 2,
  'TEAM': 3,
  'ENTERPRISE': 4
};

export default function SubscriptionGuard({ 
  children, 
  requiredPlan = 'DISCOVERY',
  requiredPlans = null,
  fallbackUrl = '/Pricing'
}) {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const navigate = useNavigate();

  const checkAccess = useCallback(async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const userSubs = await Subscription.filter({
        user_email: currentUser.email,
        status: 'Active'
      }, '-start_date', 1);

      if (!userSubs || userSubs.length === 0) {
        setHasAccess(false);
        setIsLoading(false);
        return;
      }

      const activeSub = userSubs[0];
      setSubscription(activeSub);

      const userPlanLevel = PLAN_HIERARCHY[activeSub.plan_code] || 0;
      const requiredLevel = PLAN_HIERARCHY[requiredPlan] || 0;

      if (requiredPlans && Array.isArray(requiredPlans)) {
        setHasAccess(requiredPlans.includes(activeSub.plan_code));
      } else {
        setHasAccess(userPlanLevel >= requiredLevel);
      }

      setIsLoading(false);
    } catch (error) {
      console.error("Erreur vérification abonnement:", error);
      setHasAccess(false);
      setIsLoading(false);
    }
  }, [requiredPlan, requiredPlans]);

  useEffect(() => {
    checkAccess();
  }, [checkAccess]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <Loader2 className="w-12 h-12 text-[#DC2626] animate-spin mx-auto mb-4" />
          <p className="text-white text-lg">Vérification de votre abonnement...</p>
        </motion.div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full"
        >
          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/20 border-red-500/30">
            <CardContent className="p-12 text-center space-y-6">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto border-2 border-red-500/30">
                <Lock className="w-10 h-10 text-red-400" />
              </div>

              <div>
                <h2 className="text-3xl font-bold text-white mb-3">
                  Accès Restreint
                </h2>
                <p className="text-red-300 text-lg mb-2">
                  Cette fonctionnalité nécessite un abonnement{" "}
                  <span className="font-bold">{requiredPlan}</span> ou supérieur.
                </p>
                {subscription ? (
                  <p className="text-[#9CA3AF]">
                    Votre plan actuel : <span className="font-semibold text-white">{subscription.plan_name}</span>
                  </p>
                ) : (
                  <p className="text-[#9CA3AF]">
                    Vous n'avez pas d'abonnement actif.
                  </p>
                )}
              </div>

              <div className="flex items-center gap-3 p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
                <p className="text-amber-300 text-sm text-left">
                  Pour débloquer cette fonctionnalité et profiter de toutes les capacités NEA-AZEX,
                  passez à un plan supérieur.
                </p>
              </div>

              <div className="flex gap-3 justify-center">
                <Button
                  onClick={() => navigate(createPageUrl(fallbackUrl))}
                  size="lg"
                  className="bg-[#DC2626] hover:bg-[#DC2626]/90 text-white font-semibold"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Voir les Plans
                </Button>
                <Button
                  onClick={() => navigate(createPageUrl("MySubscription"))}
                  size="lg"
                  variant="outline"
                  className="border-[#9CA3AF]/40 text-[#9CA3AF] hover:bg-[#9CA3AF]/10"
                >
                  Mon Abonnement
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return <>{children}</>;
}

export function useSubscription() {
  const [subscription, setSubscription] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadSubscription = useCallback(async () => {
    try {
      const user = await User.me();
      const subs = await Subscription.filter({
        user_email: user.email,
        status: 'Active'
      }, '-start_date', 1);

      if (subs && subs.length > 0) {
        setSubscription(subs[0]);
      }
    } catch (error) {
      console.error("Erreur chargement abonnement:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSubscription();
  }, [loadSubscription]);

  const hasFeature = useCallback((featureName) => {
    if (!subscription) return false;
    // In a real application, you would check subscription.features array or similar
    // For now, it always returns true if there's an active subscription
    return true; 
  }, [subscription]);

  const getPlanLevel = useCallback(() => {
    if (!subscription) return 0;
    return PLAN_HIERARCHY[subscription.plan_code] || 0;
  }, [subscription]);

  return {
    subscription,
    isLoading,
    hasFeature,
    getPlanLevel,
    refresh: loadSubscription
  };
}
