
import React, { useState, useEffect, useCallback } from "react";
import { SubscriptionPlan } from "@/api/entities";
import { OFFICIAL_PLANS, PLAN_PROTECTION, isOfficialPlan } from "./PlanTemplate";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, Loader2, Shield, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * INITIALISATEUR DE PLANS OFFICIELS
 * 
 * Garantit que les plans officiels existent toujours dans la base
 * Vérifie leur intégrité et les recrée si nécessaires
 */
export default function PlanInitializer({ onComplete }) {
  const [status, setStatus] = useState('idle');
  const [progress, setProgress] = useState({ current: 0, total: 4 }); // Changed from 6 to 4
  const [existingPlans, setExistingPlans] = useState([]);
  const [missingPlans, setMissingPlans] = useState([]);
  const [error, setError] = useState(null);

  const initializeMissingPlans = useCallback(async (missing) => {
    setStatus('initializing');
    setProgress({ current: 0, total: missing.length });

    try {
      for (let i = 0; i < missing.length; i++) {
        const plan = missing[i];
        
        await SubscriptionPlan.create(plan);
        
        setProgress({ current: i + 1, total: missing.length });
        
        // Petit délai pour éviter rate limit
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      setStatus('success');
      if (onComplete) onComplete(true);

    } catch (err) {
      console.error("Erreur création plans:", err);
      setError(err.message);
      setStatus('error');
      if (onComplete) onComplete(false);
    }
  }, [onComplete]);

  const checkPlans = useCallback(async () => {
    setStatus('checking');
    setError(null);

    try {
      // Charger tous les plans existants
      const allPlans = await SubscriptionPlan.list('display_order');
      setExistingPlans(allPlans || []);

      // Identifier les plans manquants
      const existingCodes = (allPlans || []).map(p => p.plan_code);
      const missing = OFFICIAL_PLANS.filter(
        official => !existingCodes.includes(official.plan_code)
      );

      setMissingPlans(missing);

      if (missing.length > 0) {
        // Des plans manquent, les créer
        await initializeMissingPlans(missing);
      } else {
        // Tous les plans existent
        setStatus('success');
        if (onComplete) onComplete(true);
      }

    } catch (err) {
      console.error("Erreur vérification plans:", err);
      setError(err.message);
      setStatus('error');
      if (onComplete) onComplete(false);
    }
  }, [initializeMissingPlans, onComplete]);

  useEffect(() => {
    checkPlans();
  }, [checkPlans]);

  if (status === 'idle' || status === 'checking') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50"
      >
        <Card className="bg-[#1c1c1c] border-[#d4af37]/30 max-w-md w-full mx-4">
          <CardContent className="p-8 text-center space-y-4">
            <Loader2 className="w-12 h-12 text-[#d4af37] animate-spin mx-auto" />
            <div>
              <h3 className="text-xl font-bold text-white mb-2">
                Vérification des Plans Officiels
              </h3>
              <p className="text-[#9CA3AF] text-sm">
                Contrôle d'intégrité du système d'abonnement...
              </p>
            </div>
            <div className="flex items-center gap-2 justify-center text-[#d4af37] text-xs">
              <Shield className="w-4 h-4" />
              <span>Système sécurisé NEA-AZEX</span>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  if (status === 'initializing') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50"
      >
        <Card className="bg-[#1c1c1c] border-[#d4af37]/30 max-w-md w-full mx-4">
          <CardContent className="p-8 space-y-6">
            <div className="text-center">
              <Loader2 className="w-12 h-12 text-[#d4af37] animate-spin mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">
                Initialisation des Plans Manquants
              </h3>
              <p className="text-[#9CA3AF] text-sm">
                Création des plans officiels dans la base de données...
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-[#9CA3AF]">Progression</span>
                <span className="text-[#d4af37] font-mono font-semibold">
                  {progress.current} / {progress.total}
                </span>
              </div>
              <div className="w-full h-2 bg-[#2a2a2a] rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(progress.current / progress.total) * 100}%` }}
                  transition={{ duration: 0.3 }}
                  className="h-full bg-gradient-to-r from-[#d4af37] to-[#f0d98f]"
                />
              </div>
            </div>

            <div className="space-y-2">
              {missingPlans.slice(0, progress.current).map((plan, idx) => (
                <motion.div
                  key={plan.plan_code}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-center gap-2 p-2 bg-green-500/10 border border-green-500/30 rounded"
                >
                  <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                  <span className="text-green-300 text-sm">{plan.plan_name}</span>
                  <Badge className="ml-auto bg-green-500/20 text-green-300 border-green-500/30 text-xs">
                    Créé
                  </Badge>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  if (status === 'success') {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
          >
            <Card className="bg-gradient-to-br from-green-900/30 to-green-800/30 border-green-500/30 max-w-md w-full mx-4">
              <CardContent className="p-8 text-center space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, damping: 15 }}
                >
                  <CheckCircle className="w-16 h-16 text-green-400 mx-auto" />
                </motion.div>
                
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    Plans Vérifiés ✓
                  </h3>
                  <p className="text-green-300">
                    Les 4 plans officiels NEA-AZEX sont actifs et protégés.
                  </p>
                </div>

                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
                  <p className="text-green-300 text-xs">
                    <Shield className="w-3 h-3 inline mr-1" />
                    Version {PLAN_PROTECTION.VERSION} • {PLAN_PROTECTION.LAST_UPDATE}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  if (status === 'error') {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-50"
      >
        <Card className="bg-gradient-to-br from-red-900/30 to-red-800/30 border-red-500/30 max-w-md w-full mx-4">
          <CardContent className="p-8 text-center space-y-4">
            <AlertTriangle className="w-16 h-16 text-red-400 mx-auto" />
            
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">
                Erreur d'Initialisation
              </h3>
              <p className="text-red-300 text-sm">
                {error || "Impossible d'initialiser les plans officiels"}
              </p>
            </div>

            <Button
              onClick={checkPlans}
              className="bg-[#DC2626] hover:bg-[#DC2626]/90 text-white"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Réessayer
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return null;
}
