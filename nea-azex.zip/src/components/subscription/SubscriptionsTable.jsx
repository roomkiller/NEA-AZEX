import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Search, ChevronsUpDown } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import NeaCard from '../ui/NeaCard';

const statusColors = {
    Active: "bg-green-500",
    Trial: "bg-blue-500",
    Cancelled: "bg-red-500",
    Pending: "bg-yellow-500",
    Expired: "bg-gray-500",
};

const SubscriptionsTable = () => {
    const [subscriptions, setSubscriptions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortConfig, setSortConfig] = useState({ key: 'start_date', direction: 'descending' });

    useEffect(() => {
        const fetchSubscriptions = async () => {
            setIsLoading(true);
            try {
                const subs = await base44.entities.Subscription.list();
                setSubscriptions(subs);
            } catch (error) {
                console.error("Error fetching subscriptions:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchSubscriptions();
    }, []);

    const sortedSubscriptions = React.useMemo(() => {
        let sortableItems = [...subscriptions];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [subscriptions, sortConfig]);

    const filteredSubscriptions = sortedSubscriptions.filter(sub =>
        sub.user_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.plan_name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const requestSort = (key) => {
        let direction = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    return (
        <NeaCard>
            <div className="p-4 border-b border-[var(--nea-border-default)]">
                <div className="flex items-center justify-between">
                    <h3 className="font-bold text-gray-900 dark:text-white">Tous les Abonnements</h3>
                    <div className="relative w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--nea-text-muted)]" />
                        <Input
                            placeholder="Rechercher par email ou forfait..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </div>
            </div>
            {isLoading ? (
                <div className="flex justify-center items-center p-8"><Loader2 className="animate-spin text-gray-900 dark:text-white" /></div>
            ) : (
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="text-gray-900 dark:text-white">Statut</TableHead>
                                <TableHead onClick={() => requestSort('user_email')} className="cursor-pointer text-gray-900 dark:text-white">
                                    <div className="flex items-center gap-2">Utilisateur <ChevronsUpDown className="w-4 h-4" /></div>
                                </TableHead>
                                <TableHead className="text-gray-900 dark:text-white">Forfait</TableHead>
                                <TableHead onClick={() => requestSort('start_date')} className="cursor-pointer text-gray-900 dark:text-white">
                                    <div className="flex items-center gap-2">Date de début <ChevronsUpDown className="w-4 h-4" /></div>
                                </TableHead>
                                <TableHead className="text-gray-900 dark:text-white">Prochaine Facture</TableHead>
                                <TableHead className="text-right text-gray-900 dark:text-white">Prix Mensuel</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredSubscriptions.map(sub => (
                                <TableRow key={sub.id}>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <span className={`w-2 h-2 rounded-full ${statusColors[sub.status] || 'bg-gray-400'}`}></span>
                                            <span className="text-gray-900 dark:text-white">{sub.status}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-gray-900 dark:text-white">{sub.user_email}</TableCell>
                                    <TableCell className="text-gray-900 dark:text-white">{sub.plan_name}</TableCell>
                                    <TableCell className="text-gray-900 dark:text-white">{new Date(sub.start_date).toLocaleDateString('fr-CA')}</TableCell>
                                    <TableCell className="text-gray-900 dark:text-white">{new Date(sub.next_billing_date).toLocaleDateString('fr-CA')}</TableCell>
                                    <TableCell className="text-right text-gray-900 dark:text-white">${sub.monthly_price.toFixed(2)}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            )}
        </NeaCard>
    );
};

export default SubscriptionsTable;