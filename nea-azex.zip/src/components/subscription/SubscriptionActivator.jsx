import { Subscription } from "@/api/entities";
import { SubscriptionPlan } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { PaymentLog } from "@/api/entities";
import { StripeTransaction } from "@/api/entities";

/**
 * SERVICE D'ACTIVATION AUTOMATIQUE D'ABONNEMENT
 * Activé par les webhooks Stripe après paiement réussi
 */

export class SubscriptionActivator {
  
  /**
   * Active un abonnement après paiement Stripe
   */
  static async activateFromStripePayment(stripeSessionData) {
    try {
      const {
        customer_email,
        customer_name,
        plan_code,
        billing_cycle,
        amount_total,
        payment_intent,
        subscription_id: stripeSubscriptionId
      } = stripeSessionData;

      // 1. Charger le plan
      const plans = await SubscriptionPlan.filter({ plan_code });
      if (!plans || plans.length === 0) {
        throw new Error(`Plan ${plan_code} introuvable`);
      }
      const plan = plans[0];

      // 2. Calculer dates
      const startDate = new Date();
      const endDate = new Date(startDate);
      
      if (billing_cycle === 'yearly') {
        endDate.setFullYear(endDate.getFullYear() + 1);
      } else {
        endDate.setMonth(endDate.getMonth() + 1);
      }

      // 3. Vérifier si abonnement existant
      const existingSubs = await Subscription.filter({
        user_email: customer_email,
        plan_code
      }, '-created_date', 1);

      let subscription;

      if (existingSubs && existingSubs.length > 0) {
        // Mettre à jour l'abonnement existant
        subscription = await Subscription.update(existingSubs[0].id, {
          status: 'Active',
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString(),
          billing_cycle: billing_cycle === 'yearly' ? 'Yearly' : 'Monthly',
          monthly_price: billing_cycle === 'yearly' ? plan.yearly_price / 12 : plan.monthly_price,
          payment_status: 'Paid',
          last_payment_date: startDate.toISOString(),
          next_billing_date: endDate.toISOString(),
          total_paid: amount_total / 100,
          auto_renew: true
        });
      } else {
        // Créer nouvel abonnement
        subscription = await Subscription.create({
          user_email: customer_email,
          plan_code,
          plan_name: plan.plan_name,
          status: 'Active',
          billing_cycle: billing_cycle === 'yearly' ? 'Yearly' : 'Monthly',
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString(),
          monthly_price: billing_cycle === 'yearly' ? plan.yearly_price / 12 : plan.monthly_price,
          currency: 'CAD',
          payment_method: 'Stripe',
          payment_status: 'Paid',
          last_payment_date: startDate.toISOString(),
          next_billing_date: endDate.toISOString(),
          total_paid: amount_total / 100,
          auto_renew: true,
          usage_stats: {
            predictions_used: 0,
            modules_active: 0,
            api_calls_today: 0,
            last_login: startDate.toISOString()
          }
        });
      }

      // 4. Créer transaction Stripe
      await StripeTransaction.create({
        stripe_session_id: stripeSessionData.id,
        stripe_payment_intent_id: payment_intent,
        stripe_customer_id: stripeSessionData.customer,
        user_email: customer_email,
        plan_code,
        amount: amount_total,
        currency: 'cad',
        billing_cycle: billing_cycle === 'yearly' ? 'yearly' : 'monthly',
        status: 'completed',
        payment_status: 'paid',
        stripe_event_type: 'checkout.session.completed',
        subscription_id: subscription.id,
        completed_at: startDate.toISOString(),
        webhook_received_at: new Date().toISOString()
      });

      // 5. Créer facture
      const invoiceNumber = `INV-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      
      await Invoice.create({
        invoice_number: invoiceNumber,
        user_email: customer_email,
        subscription_id: subscription.id,
        invoice_date: startDate.toISOString(),
        due_date: startDate.toISOString(),
        billing_period_start: startDate.toISOString().split('T')[0],
        billing_period_end: endDate.toISOString().split('T')[0],
        line_items: [{
          description: `${plan.plan_name} - ${billing_cycle === 'yearly' ? 'Annuel' : 'Mensuel'}`,
          quantity: 1,
          unit_price: amount_total / 100,
          total: amount_total / 100
        }],
        subtotal: amount_total / 100,
        tax_rate: 14.975,
        tax_amount: (amount_total / 100) * 0.14975,
        total_amount: amount_total / 100,
        currency: 'CAD',
        status: 'Paid',
        paid_date: startDate.toISOString(),
        payment_method: 'Stripe',
        payment_reference: payment_intent,
        sent_to_client: true,
        sent_date: startDate.toISOString()
      });

      // 6. Logger le paiement
      await PaymentLog.create({
        transaction_id: payment_intent,
        user_email: customer_email,
        subscription_id: subscription.id,
        amount: amount_total / 100,
        currency: 'CAD',
        payment_method: 'Stripe',
        payment_date: startDate.toISOString(),
        status: 'Completed',
        reference_number: payment_intent
      });

      console.log(`✅ Abonnement activé pour ${customer_email} - ${plan.plan_name}`);

      return {
        success: true,
        subscription,
        message: `Abonnement ${plan.plan_name} activé avec succès`
      };

    } catch (error) {
      console.error("❌ Erreur activation abonnement:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Vérifie et renouvelle les abonnements expirés
   */
  static async checkAndRenewSubscriptions() {
    try {
      const now = new Date();
      
      // Trouver abonnements arrivant à expiration dans les 7 jours
      const subscriptions = await Subscription.filter({
        status: 'Active',
        auto_renew: true
      });

      for (const sub of subscriptions) {
        const endDate = new Date(sub.end_date);
        const daysUntilExpiry = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));

        if (daysUntilExpiry <= 7 && daysUntilExpiry > 0) {
          console.log(`⚠️ Abonnement ${sub.user_email} expire dans ${daysUntilExpiry} jours`);
          // TODO: Déclencher email de rappel
        }

        if (daysUntilExpiry <= 0) {
          console.log(`❌ Abonnement ${sub.user_email} expiré - Suspension`);
          await Subscription.update(sub.id, {
            status: 'Expired'
          });
        }
      }

    } catch (error) {
      console.error("Erreur vérification abonnements:", error);
    }
  }
}