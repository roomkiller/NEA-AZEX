import { isOfficialPlan } from "./PlanTemplate";

/**
 * SYSTÈME DE PROTECTION DES PLANS OFFICIELS
 * 
 * Empêche la modification ou suppression des 6 plans officiels
 */

export function canModifyPlan(planCode) {
  if (isOfficialPlan(planCode)) {
    return {
      allowed: false,
      reason: "Ce plan est un plan officiel NEA-AZEX et ne peut pas être modifié. Il est protégé par le système."
    };
  }
  
  return { allowed: true };
}

export function canDeletePlan(planCode) {
  if (isOfficialPlan(planCode)) {
    return {
      allowed: false,
      reason: "Ce plan est un plan officiel NEA-AZEX et ne peut pas être supprimé. Il est essentiel au fonctionnement du système."
    };
  }
  
  return { allowed: true };
}

/**
 * Wrapper sécurisé pour la modification de plans
 */
export async function safeUpdatePlan(planId, planCode, updateData, updateFunction) {
  const protection = canModifyPlan(planCode);
  
  if (!protection.allowed) {
    throw new Error(protection.reason);
  }
  
  return await updateFunction(planId, updateData);
}

/**
 * Wrapper sécurisé pour la suppression de plans
 */
export async function safeDeletePlan(planId, planCode, deleteFunction) {
  const protection = canDeletePlan(planCode);
  
  if (!protection.allowed) {
    throw new Error(protection.reason);
  }
  
  return await deleteFunction(planId);
}