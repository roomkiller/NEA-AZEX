import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import NeaButton from '../ui/NeaButton';
import NeaCard from '../ui/NeaCard';
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import StripeCheckout from './StripeCheckout';

export default function PlanTemplate({ plan, billingCycle }) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const price = billingCycle === 'yearly' ? plan.yearly_price : plan.monthly_price;
    const period = billingCycle === 'yearly' ? '/ an' : '/ mois';

    return (
        <motion.div
            variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
            }}
        >
            <NeaCard className={`h-full flex flex-col p-8 relative overflow-hidden ${plan.is_popular ? 'border-[var(--nea-primary-blue)]' : ''}`}>
                {plan.is_popular && (
                     <div className="absolute top-0 right-0 h-16 w-16">
                        <div className="absolute transform rotate-45 bg-[var(--nea-primary-blue)] text-center text-white font-semibold py-1 right-[-34px] top-[32px] w-[170px]">
                            Populaire
                        </div>
                    </div>
                )}
                
                <h3 className="text-lg font-semibold text-white">{plan.plan_name}</h3>
                <p className="mt-4 text-[var(--nea-text-secondary)] flex-grow">{plan.description}</p>
                
                <div className="mt-8">
                    <p className="text-4xl font-bold text-white">${price}<span className="text-lg font-medium text-[var(--nea-text-secondary)]">{period}</span></p>
                </div>

                <ul className="mt-8 space-y-4 text-sm text-[var(--nea-text-secondary)]">
                    {(plan.features || []).map((feature, index) => (
                        <li key={index} className="flex items-center">
                            <Check className="w-4 h-4 mr-3 text-green-500" />
                            <span>{feature}</span>
                        </li>
                    ))}
                </ul>

                <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                    <DialogTrigger asChild>
                         <NeaButton variant={plan.is_popular ? "primary" : "secondary"} className="w-full mt-10">
                            S'abonner
                        </NeaButton>
                    </DialogTrigger>
                    <DialogContent className="bg-[var(--nea-bg-surface)] border-[var(--nea-border-default)]">
                        <StripeCheckout plan={plan} billingCycle={billingCycle} onFinished={() => setIsModalOpen(false)} />
                    </DialogContent>
                </Dialog>
            </NeaCard>
        </motion.div>
    );
}