import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useOnClickOutside } from '../hooks/useOnClickOutside';

/**
 * TOOLTIP
 * Info-bulle accessible au survol ou au focus
 */
export default function Tooltip({
  children,
  content,
  position = 'top', // top, bottom, left, right
  delay = 200,
  className = ''
}) {
  const [isVisible, setIsVisible] = useState(false);
  const [timeoutId, setTimeoutId] = useState(null);
  const tooltipRef = useRef(null);

  const showTooltip = () => {
    const id = setTimeout(() => {
      setIsVisible(true);
    }, delay);
    setTimeoutId(id);
  };

  const hideTooltip = () => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    setIsVisible(false);
  };

  useOnClickOutside(tooltipRef, hideTooltip);

  const positionClasses = {
    top: 'bottom-full left-1/2 transform -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 transform -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 transform -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 transform -translate-y-1/2 ml-2'
  };

  const arrowClasses = {
    top: 'top-full left-1/2 transform -translate-x-1/2 border-t-[var(--nea-bg-surface)] border-x-transparent border-b-transparent',
    bottom: 'bottom-full left-1/2 transform -translate-x-1/2 border-b-[var(--nea-bg-surface)] border-x-transparent border-t-transparent',
    left: 'left-full top-1/2 transform -translate-y-1/2 border-l-[var(--nea-bg-surface)] border-y-transparent border-r-transparent',
    right: 'right-full top-1/2 transform -translate-y-1/2 border-r-[var(--nea-bg-surface)] border-y-transparent border-l-transparent'
  };

  return (
    <div 
      className="relative inline-flex"
      ref={tooltipRef}
      onMouseEnter={showTooltip}
      onMouseLeave={hideTooltip}
      onFocus={showTooltip}
      onBlur={hideTooltip}
    >
      {children}
      
      <AnimatePresence>
        {isVisible && content && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className={cn(
              "absolute z-50 px-3 py-2 text-sm text-white bg-[var(--nea-bg-surface)] border border-[var(--nea-border-default)] rounded-lg shadow-lg whitespace-nowrap",
              positionClasses[position],
              className
            )}
            role="tooltip"
          >
            {content}
            {/* Arrow */}
            <div 
              className={cn(
                "absolute w-0 h-0 border-4",
                arrowClasses[position]
              )}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}