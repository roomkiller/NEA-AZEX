import React, { useState, createContext, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * ACCORDION COMPONENT
 * Accordéon accessible avec animations fluides
 */
const AccordionContext = createContext(null);

export function Accordion({ type = 'single', defaultValue, children, className = '' }) {
  const [openItems, setOpenItems] = useState(
    defaultValue 
      ? (type === 'single' ? [defaultValue] : defaultValue)
      : []
  );

  const toggleItem = (value) => {
    if (type === 'single') {
      setOpenItems(openItems.includes(value) ? [] : [value]);
    } else {
      setOpenItems(
        openItems.includes(value)
          ? openItems.filter(item => item !== value)
          : [...openItems, value]
      );
    }
  };

  return (
    <AccordionContext.Provider value={{ openItems, toggleItem }}>
      <div className={cn("space-y-2", className)}>
        {children}
      </div>
    </AccordionContext.Provider>
  );
}

export function AccordionItem({ value, children, className = '' }) {
  const context = useContext(AccordionContext);
  const isOpen = context.openItems.includes(value);

  return (
    <div
      className={cn(
        "border border-[var(--nea-border-default)] rounded-lg overflow-hidden",
        "bg-[var(--nea-bg-surface)]",
        className
      )}
    >
      {React.Children.map(children, child =>
        React.cloneElement(child, { value, isOpen })
      )}
    </div>
  );
}

export function AccordionTrigger({ value, isOpen, children, className = '' }) {
  const context = useContext(AccordionContext);

  return (
    <button
      onClick={() => context.toggleItem(value)}
      className={cn(
        "w-full flex items-center justify-between p-4",
        "text-left text-[var(--nea-text-primary)] font-medium",
        "hover:bg-[var(--nea-bg-surface-hover)] transition-colors",
        "focus:outline-none focus:ring-2 focus:ring-[var(--nea-primary-blue)] focus:ring-offset-2",
        className
      )}
      aria-expanded={isOpen}
      aria-controls={`content-${value}`}
    >
      <span>{children}</span>
      <motion.div
        animate={{ rotate: isOpen ? 180 : 0 }}
        transition={{ duration: 0.2 }}
      >
        <ChevronDown className="w-5 h-5 text-[var(--nea-text-secondary)]" />
      </motion.div>
    </button>
  );
}

export function AccordionContent({ value, isOpen, children, className = '' }) {
  return (
    <AnimatePresence initial={false}>
      {isOpen && (
        <motion.div
          id={`content-${value}`}
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="overflow-hidden"
        >
          <div className={cn("p-4 pt-0 text-[var(--nea-text-secondary)]", className)}>
            {children}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}