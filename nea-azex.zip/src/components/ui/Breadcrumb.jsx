import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { cn } from '@/lib/utils';
import { createPageUrl } from '@/utils';

/**
 * BREADCRUMB COMPONENT
 * Fil d'Ariane amélioré et accessible
 */
export default function Breadcrumb({ items = [], showHome = true, className = '' }) {
  return (
    <nav
      aria-label="Fil d'Ariane"
      className={cn("flex items-center gap-2 text-sm", className)}
    >
      <ol className="flex items-center gap-2 flex-wrap" role="list">
        {showHome && (
          <li role="listitem">
            <Link
              to="/"
              className="flex items-center gap-1 text-[var(--nea-text-secondary)] hover:text-[var(--nea-text-primary)] transition-colors"
            >
              <Home className="w-4 h-4" />
              <span className="sr-only">Accueil</span>
            </Link>
            <ChevronRight className="w-4 h-4 text-[var(--nea-text-muted)] inline-block ml-2" aria-hidden="true" />
          </li>
        )}

        {items.map((item, index) => {
          const isLast = index === items.length - 1;

          return (
            <li key={index} role="listitem" className="flex items-center gap-2">
              {item.href && !isLast ? (
                <Link
                  to={createPageUrl(item.href)}
                  className="text-[var(--nea-text-secondary)] hover:text-[var(--nea-text-primary)] transition-colors"
                >
                  {item.label}
                </Link>
              ) : (
                <span
                  className={cn(
                    isLast
                      ? "font-semibold text-[var(--nea-text-title)]"
                      : "text-[var(--nea-text-secondary)]"
                  )}
                  aria-current={isLast ? 'page' : undefined}
                >
                  {item.label}
                </span>
              )}

              {!isLast && (
                <ChevronRight className="w-4 h-4 text-[var(--nea-text-muted)]" aria-hidden="true" />
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}