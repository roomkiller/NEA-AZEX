import React, { useState } from "react";
import { StripeTransaction } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CreditCard, Lock, CheckCircle, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function StripeCheckout({ plan, billingCycle = "monthly", onSuccess, onCancel }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);

  const amount = billingCycle === "yearly" ? plan.yearly_price : plan.monthly_price;
  const amountInCents = Math.round(amount * 100);

  const handleCheckout = async () => {
    setIsProcessing(true);
    setError(null);

    try {
      const currentUser = await User.me();

      // Créer une transaction dans notre base
      const transaction = await StripeTransaction.create({
        user_email: currentUser.email,
        plan_code: plan.plan_code,
        amount: amountInCents,
        currency: "cad",
        billing_cycle: billingCycle,
        status: "pending"
      });

      // IMPORTANT: Pour l'instant, simulation du paiement
      // Dans une vraie intégration, vous devrez appeler Stripe Checkout
      
      // Simuler un délai de traitement
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Pour l'instant: créer directement l'abonnement
      // TODO: Remplacer par vraie intégration Stripe
      const { Subscription } = await import("@/api/entities");
      
      const startDate = new Date();
      const endDate = new Date(startDate);
      if (billingCycle === "yearly") {
        endDate.setFullYear(endDate.getFullYear() + 1);
      } else {
        endDate.setMonth(endDate.getMonth() + 1);
      }

      await Subscription.create({
        user_email: currentUser.email,
        plan_code: plan.plan_code,
        plan_name: plan.plan_name,
        status: "Active",
        billing_cycle: billingCycle === "yearly" ? "Yearly" : "Monthly",
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        monthly_price: plan.monthly_price,
        currency: "CAD",
        payment_method: "Stripe",
        payment_status: "Paid",
        auto_renew: true
      });

      // Mettre à jour la transaction
      await StripeTransaction.update(transaction.id, {
        status: "completed",
        payment_status: "paid",
        completed_at: new Date().toISOString()
      });

      if (onSuccess) onSuccess();

    } catch (err) {
      console.error("Erreur checkout:", err);
      setError(err.message || "Erreur lors du paiement");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card className="bg-[#1c1c1c]/50 border-[#d4af37]/30">
      <CardContent className="p-6 space-y-4">
        {/* Résumé Commande */}
        <div className="space-y-3">
          <h3 className="text-white font-bold text-lg">Récapitulatif</h3>
          
          <div className="flex justify-between items-center py-2 border-b border-[#d4af37]/10">
            <span className="text-[#c0c0c0]">Plan</span>
            <span className="text-white font-semibold">{plan.plan_name}</span>
          </div>

          <div className="flex justify-between items-center py-2 border-b border-[#d4af37]/10">
            <span className="text-[#c0c0c0]">Facturation</span>
            <Badge className="bg-[#d4af37]/10 text-[#d4af37] border-[#d4af37]/30">
              {billingCycle === "yearly" ? "Annuelle" : "Mensuelle"}
            </Badge>
          </div>

          {billingCycle === "yearly" && plan.yearly_price && (
            <div className="flex justify-between items-center py-2 border-b border-emerald-500/20">
              <span className="text-emerald-400 text-sm">Économie</span>
              <span className="text-emerald-400 font-semibold">
                {((plan.monthly_price * 12) - plan.yearly_price).toFixed(0)} $ CAD
              </span>
            </div>
          )}

          <div className="flex justify-between items-center py-3 border-t-2 border-[#d4af37]/30">
            <span className="text-white font-bold">Total</span>
            <div className="text-right">
              <p className="text-[#d4af37] font-bold text-2xl font-mono">{amount} $</p>
              <p className="text-[#c0c0c0] text-xs">
                {billingCycle === "yearly" ? "par an" : "par mois"} • CAD
              </p>
            </div>
          </div>
        </div>

        {/* Message Erreur */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-red-900/20 border border-red-500/30 rounded-lg p-3 flex items-start gap-2"
            >
              <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-400 font-semibold text-sm">Erreur de paiement</p>
                <p className="text-red-300 text-xs mt-1">{error}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sécurité */}
        <div className="flex items-center gap-2 text-[#c0c0c0] text-xs bg-[#2a2a2a]/30 rounded-lg p-3">
          <Lock className="w-4 h-4 text-[#d4af37]" />
          <span>Paiement sécurisé • Chiffrement SSL • Stripe certifié PCI DSS</span>
        </div>

        {/* Boutons */}
        <div className="flex gap-3">
          {onCancel && (
            <Button
              onClick={onCancel}
              disabled={isProcessing}
              variant="outline"
              className="flex-1 border-[#d4af37]/30 text-[#d4af37] hover:bg-[#d4af37]/10"
            >
              Annuler
            </Button>
          )}
          <Button
            onClick={handleCheckout}
            disabled={isProcessing}
            className="flex-1 bg-[#d4af37] hover:bg-[#b8941f] text-black font-bold"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Traitement...
              </>
            ) : (
              <>
                <CreditCard className="w-4 h-4 mr-2" />
                Payer {amount} $ CAD
              </>
            )}
          </Button>
        </div>

        {/* Info Trial */}
        {plan.trial_days > 0 && (
          <div className="bg-emerald-900/20 border border-emerald-500/30 rounded-lg p-3 flex items-start gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-emerald-400 font-semibold text-sm">Essai gratuit {plan.trial_days} jours</p>
              <p className="text-emerald-300 text-xs mt-1">
                Annulez avant le {new Date(Date.now() + plan.trial_days * 24 * 60 * 60 * 1000).toLocaleDateString('fr-FR')} pour ne rien payer
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}